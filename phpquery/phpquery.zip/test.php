<?php  

/**
 * 一个简易的网页爬虫
 * @author iqiqiya
 * @copyright 2018 77sec.cn
 */

require('phpQuery/phpQuery.php');

$link = "https://new.qq.com/omn/20190212/20190212V0NCV3.html";


$content = file_get_contents($link);

$content = iconv("gb2312", "utf-8//IGNORE", $content);

//echo $content;

phpQuery::newDocumentFile($content); //以html内容的方式进行初始化
//phpQuery::newDocumentFile($link); //初始化一个实例

//$title = pq(".post_content_main h1")->text();

$title = pq(".LEFT h1")->text();

var_dump($title); //输出
?>